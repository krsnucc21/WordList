# pomenohenn-pyxel
pomenohenn but with a pyxel interface.

 <img src="https://user-images.githubusercontent.com/24848927/141817712-e1a878c4-299b-4185-93dc-ab9d630f5057.png" width="450">
 <img src="https://user-images.githubusercontent.com/24848927/141813387-09d0559d-7cf8-4c53-8b8a-b07df14d81e5.png" width="450">
 
 The answer here is **phoenix**

### Instructions
Unscramble the letters correctly. Complete ten questions to win!

### Download (Windows)
Download `dist/pomenohenn.exe`

**Building for other environments**

You need to run `pip install` on `pyxel` and `pyinstaller`

`pyxelpackager main.py`
